package com.example.createboost;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.common.world.chunk.RegisterTicketControllersEvent;
import net.minecraftforge.common.world.chunk.TicketController;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;

@Mod(CreateBoost.MODID)
public class CreateBoost {
    public static final String MODID = "createboost";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<Block> ANCHOR = BLOCKS.register("mechanism_anchor",
            () -> new ChunkAnchorBlock(BlockBehaviour.Properties.of()
                    .strength(4.0f, 8.0f)
                    .sound(SoundType.METAL)
                    .lightLevel(s -> 6)
                    .requiresCorrectToolForDrops()));
    public static final RegistryObject<Item> ANCHOR_ITEM = ITEMS.register("mechanism_anchor",
            () -> new BlockItem(ANCHOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> CONTROL_BOARD = ITEMS.register("control_board",
            () -> new Item(new Item.Properties()));

    /** Owns the forced-chunk tickets; stale tickets are cleaned on world load. */
    public static final TicketController CONTROLLER = new TicketController(
            new ResourceLocation(MODID, "anchors"),
            (level, helper) -> {
                AnchorData data = AnchorData.get(level);
                for (var pos : new ArrayList<>(helper.getBlockTickets().keySet())) {
                    AnchorData.Entry e = data.get(pos);
                    boolean valid = level.getBlockState(pos).is(ANCHOR.get())
                            && e != null && e.partner != null
                            && AnchorManager.master(pos, e.partner).equals(pos);
                    if (!valid) helper.removeAllTickets(pos);
                }
            });

    public CreateBoost() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, BoostConfig.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, BoostConfig.COMMON_SPEC);
        BLOCKS.register(bus);
        ITEMS.register(bus);
        bus.addListener((RegisterTicketControllersEvent e) -> e.register(CONTROLLER));
        bus.addListener((BuildCreativeModeTabContentsEvent e) -> {
            if (e.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) e.accept(ANCHOR_ITEM);
            if (e.getTabKey() == CreativeModeTabs.INGREDIENTS) e.accept(CONTROL_BOARD);
        });
    }
}
