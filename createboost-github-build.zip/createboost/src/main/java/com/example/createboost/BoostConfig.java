package com.example.createboost;

import net.minecraftforge.common.ForgeConfigSpec;

public class BoostConfig {
    public static final ForgeConfigSpec SPEC;          // client
    public static final ForgeConfigSpec COMMON_SPEC;   // server/common
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.IntValue CULL_DISTANCE;
    public static final ForgeConfigSpec.IntValue FAR_TICK_INTERVAL;
    public static final ForgeConfigSpec.IntValue MAX_SIDE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("client");
        ENABLED = b.comment("Enable skipping client ticks of far Create kinetic blocks")
                .define("enabled", true);
        CULL_DISTANCE = b.comment("Distance (blocks) beyond which kinetic blocks tick rarely")
                .defineInRange("cullDistance", 48, 16, 256);
        FAR_TICK_INTERVAL = b.comment("Far blocks tick once per N game ticks")
                .defineInRange("farTickInterval", 10, 2, 100);
        b.pop();
        SPEC = b.build();

        ForgeConfigSpec.Builder c = new ForgeConfigSpec.Builder();
        c.push("anchors");
        MAX_SIDE = c.comment("Max territory side length in chunks between two Mechanism Anchors")
                .defineInRange("maxSideChunks", 8, 1, 32);
        c.pop();
        COMMON_SPEC = c.build();
    }

    private static volatile int cachedDistSq = 48 * 48;

    public static boolean enabled() {
        try { return ENABLED.get(); } catch (Throwable t) { return false; }
    }

    public static int distSq() {
        try {
            int d = CULL_DISTANCE.get();
            cachedDistSq = d * d;
        } catch (Throwable ignored) { }
        return cachedDistSq;
    }

    public static int interval() {
        try { return FAR_TICK_INTERVAL.get(); } catch (Throwable t) { return 10; }
    }
}
