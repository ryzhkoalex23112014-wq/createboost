package com.example.createboost;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/** Pairing logic: two anchors define a rectangle of chunks that stays loaded. */
public final class AnchorManager {
    private AnchorManager() { }

    public static BlockPos master(BlockPos a, BlockPos b) {
        return a.asLong() <= b.asLong() ? a : b;
    }

    public static void onPlaced(ServerLevel level, ServerPlayer player, BlockPos pos) {
        AnchorData data = AnchorData.get(level);

        BlockPos other = data.findPending(player.getUUID(), pos);
        while (other != null && level.isLoaded(other) && !level.getBlockState(other).is(CreateBoost.ANCHOR.get())) {
            data.remove(other); // stale record
            other = data.findPending(player.getUUID(), pos);
        }

        if (other == null) {
            data.putSingle(pos, player.getUUID());
            msg(player, Component.translatable("message.createboost.first"));
            return;
        }

        int w = Math.abs((pos.getX() >> 4) - (other.getX() >> 4)) + 1;
        int h = Math.abs((pos.getZ() >> 4) - (other.getZ() >> 4)) + 1;
        int max = BoostConfig.MAX_SIDE.get();
        if (w > max || h > max) {
            msg(player, Component.translatable("message.createboost.too_big", max, max));
            level.destroyBlock(pos, !player.isCreative()); // give the block back
            return;
        }

        data.putSingle(pos, player.getUUID());
        data.pair(pos, other);
        forceRegion(level, master(pos, other), pos, other, true);
        msg(player, Component.translatable("message.createboost.paired", w, h));
    }

    public static void onRemoved(ServerLevel level, BlockPos pos) {
        AnchorData data = AnchorData.get(level);
        AnchorData.Entry e = data.get(pos);
        if (e == null) return;

        if (e.partner != null) {
            BlockPos other = e.partner;
            forceRegion(level, master(pos, other), pos, other, false);
            data.remove(pos);
            data.release(other);
            ServerPlayer owner = level.getServer().getPlayerList().getPlayer(e.owner);
            if (owner != null) msg(owner, Component.translatable("message.createboost.released"));
        } else {
            data.remove(pos);
        }
    }

    public static void describe(ServerLevel level, Player player, BlockPos pos) {
        AnchorData.Entry e = AnchorData.get(level).get(pos);
        if (e == null || e.partner == null) {
            msg(player, Component.translatable("message.createboost.info_waiting"));
        } else {
            int w = Math.abs((pos.getX() >> 4) - (e.partner.getX() >> 4)) + 1;
            int h = Math.abs((pos.getZ() >> 4) - (e.partner.getZ() >> 4)) + 1;
            msg(player, Component.translatable("message.createboost.info_paired", w, h, e.partner.toShortString()));
        }
    }

    private static void forceRegion(ServerLevel level, BlockPos owner, BlockPos a, BlockPos b, boolean add) {
        int minX = Math.min(a.getX() >> 4, b.getX() >> 4);
        int maxX = Math.max(a.getX() >> 4, b.getX() >> 4);
        int minZ = Math.min(a.getZ() >> 4, b.getZ() >> 4);
        int maxZ = Math.max(a.getZ() >> 4, b.getZ() >> 4);
        for (int cx = minX; cx <= maxX; cx++) {
            for (int cz = minZ; cz <= maxZ; cz++) {
                CreateBoost.CONTROLLER.forceChunk(level, owner, cx, cz, add, true);
            }
        }
    }

    private static void msg(Player player, Component c) {
        player.displayClientMessage(c, true);
    }
}
