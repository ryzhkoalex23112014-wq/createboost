package com.example.createboost.mixin;

import com.example.createboost.BoostConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Create's KineticBlockEntity: on the client, far-away instances tick only
 * once every N game ticks (saves sound/particle/effect work).
 */
@Mixin(targets = "com.simibubi.create.content.kinetics.base.KineticBlockEntity", remap = false)
public abstract class KineticBlockEntityMixin {

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void createboost$skipFarTick(CallbackInfo ci) {
        if (!BoostConfig.enabled()) return;

        BlockEntity self = (BlockEntity) (Object) this;
        if (self.getLevel() == null || !self.getLevel().isClientSide) return;

        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) return;

        double distSq = player.distanceToSqr(
                self.getBlockPos().getX() + 0.5,
                self.getBlockPos().getY() + 0.5,
                self.getBlockPos().getZ() + 0.5);

        if (distSq > BoostConfig.distSq()) {
            long t = self.getLevel().getGameTime();
            // spread far blocks across ticks using their position hash
            if ((t + self.getBlockPos().hashCode()) % BoostConfig.interval() != 0) {
                ci.cancel();
            }
        }
    }
}
