package com.example.createboost;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Per-dimension storage of anchors, their owners and their partners. */
public class AnchorData extends SavedData {
    private static final String NAME = "createboost_anchors";

    public static class Entry {
        public UUID owner;
        public BlockPos partner; // null = waiting for a pair
        public long order;

        Entry(UUID owner, BlockPos partner, long order) {
            this.owner = owner;
            this.partner = partner;
            this.order = order;
        }
    }

    private final Map<BlockPos, Entry> anchors = new HashMap<>();
    private long counter = 0;

    public static AnchorData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(AnchorData::load, AnchorData::new, NAME);
    }

    public Entry get(BlockPos pos) {
        return anchors.get(pos);
    }

    public void putSingle(BlockPos pos, UUID owner) {
        anchors.put(pos.immutable(), new Entry(owner, null, ++counter));
        setDirty();
    }

    public void pair(BlockPos a, BlockPos b) {
        Entry ea = anchors.get(a);
        Entry eb = anchors.get(b);
        if (ea == null || eb == null) return;
        ea.partner = b.immutable();
        eb.partner = a.immutable();
        setDirty();
    }

    public void release(BlockPos pos) {
        Entry e = anchors.get(pos);
        if (e != null) {
            e.partner = null;
            e.order = ++counter;
            setDirty();
        }
    }

    public Entry remove(BlockPos pos) {
        Entry e = anchors.remove(pos);
        if (e != null) setDirty();
        return e;
    }

    /** Most recently placed unpaired anchor of this owner. */
    public BlockPos findPending(UUID owner, BlockPos exclude) {
        BlockPos best = null;
        long bestOrder = -1;
        for (Map.Entry<BlockPos, Entry> en : anchors.entrySet()) {
            Entry e = en.getValue();
            if (e.partner == null && e.owner.equals(owner) && !en.getKey().equals(exclude) && e.order > bestOrder) {
                best = en.getKey();
                bestOrder = e.order;
            }
        }
        return best;
    }

    public static AnchorData load(CompoundTag tag) {
        AnchorData d = new AnchorData();
        d.counter = tag.getLong("counter");
        ListTag list = tag.getList("anchors", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            BlockPos pos = NbtUtils.readBlockPos(t.getCompound("pos"));
            BlockPos partner = t.contains("partner") ? NbtUtils.readBlockPos(t.getCompound("partner")) : null;
            d.anchors.put(pos, new Entry(t.getUUID("owner"), partner, t.getLong("order")));
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLong("counter", counter);
        ListTag list = new ListTag();
        for (Map.Entry<BlockPos, Entry> en : anchors.entrySet()) {
            CompoundTag t = new CompoundTag();
            t.put("pos", NbtUtils.writeBlockPos(en.getKey()));
            Entry e = en.getValue();
            if (e.partner != null) t.put("partner", NbtUtils.writeBlockPos(e.partner));
            t.putUUID("owner", e.owner);
            t.putLong("order", e.order);
            list.add(t);
        }
        tag.put("anchors", list);
        return tag;
    }
}
